#include <stdlib.h>

int main() {
    system("gnome-terminal");
    return 0;
}

